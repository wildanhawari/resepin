<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.category-resource.pages.create-category' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\CreateCategory',
    'app.filament.resources.category-resource.pages.edit-category' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\EditCategory',
    'app.filament.resources.category-resource.pages.list-categories' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\ListCategories',
    'app.filament.resources.food-ingredient-resource.pages.create-food-ingredient' => 'App\\Filament\\Resources\\FoodIngredientResource\\Pages\\CreateFoodIngredient',
    'app.filament.resources.food-ingredient-resource.pages.edit-food-ingredient' => 'App\\Filament\\Resources\\FoodIngredientResource\\Pages\\EditFoodIngredient',
    'app.filament.resources.food-ingredient-resource.pages.list-food-ingredients' => 'App\\Filament\\Resources\\FoodIngredientResource\\Pages\\ListFoodIngredients',
    'app.filament.resources.food-resource.pages.create-food' => 'App\\Filament\\Resources\\FoodResource\\Pages\\CreateFood',
    'app.filament.resources.food-resource.pages.edit-food' => 'App\\Filament\\Resources\\FoodResource\\Pages\\EditFood',
    'app.filament.resources.food-resource.pages.list-food' => 'App\\Filament\\Resources\\FoodResource\\Pages\\ListFood',
    'app.filament.resources.food-tool-resource.pages.create-food-tool' => 'App\\Filament\\Resources\\FoodToolResource\\Pages\\CreateFoodTool',
    'app.filament.resources.food-tool-resource.pages.edit-food-tool' => 'App\\Filament\\Resources\\FoodToolResource\\Pages\\EditFoodTool',
    'app.filament.resources.food-tool-resource.pages.list-food-tools' => 'App\\Filament\\Resources\\FoodToolResource\\Pages\\ListFoodTools',
    'app.filament.resources.ingredient-resource.pages.create-ingredient' => 'App\\Filament\\Resources\\IngredientResource\\Pages\\CreateIngredient',
    'app.filament.resources.ingredient-resource.pages.edit-ingredient' => 'App\\Filament\\Resources\\IngredientResource\\Pages\\EditIngredient',
    'app.filament.resources.ingredient-resource.pages.list-ingredients' => 'App\\Filament\\Resources\\IngredientResource\\Pages\\ListIngredients',
    'app.filament.resources.tool-resource.pages.create-tool' => 'App\\Filament\\Resources\\ToolResource\\Pages\\CreateTool',
    'app.filament.resources.tool-resource.pages.edit-tool' => 'App\\Filament\\Resources\\ToolResource\\Pages\\EditTool',
    'app.filament.resources.tool-resource.pages.list-tools' => 'App\\Filament\\Resources\\ToolResource\\Pages\\ListTools',
    'app.filament.resources.tutorial-resource.pages.create-tutorial' => 'App\\Filament\\Resources\\TutorialResource\\Pages\\CreateTutorial',
    'app.filament.resources.tutorial-resource.pages.edit-tutorial' => 'App\\Filament\\Resources\\TutorialResource\\Pages\\EditTutorial',
    'app.filament.resources.tutorial-resource.pages.list-tutorials' => 'App\\Filament\\Resources\\TutorialResource\\Pages\\ListTutorials',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.widgets.filament-info-widget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'D:\\System Files\\Project Laravel\\resepin\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'D:\\System Files\\Project Laravel\\resepin\\app\\Filament\\Resources\\CategoryResource.php' => 'App\\Filament\\Resources\\CategoryResource',
    'D:\\System Files\\Project Laravel\\resepin\\app\\Filament\\Resources\\FoodResource.php' => 'App\\Filament\\Resources\\FoodResource',
    'D:\\System Files\\Project Laravel\\resepin\\app\\Filament\\Resources\\IngredientResource.php' => 'App\\Filament\\Resources\\IngredientResource',
    'D:\\System Files\\Project Laravel\\resepin\\app\\Filament\\Resources\\ToolResource.php' => 'App\\Filament\\Resources\\ToolResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'D:\\System Files\\Project Laravel\\resepin\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'D:\\System Files\\Project Laravel\\resepin\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);